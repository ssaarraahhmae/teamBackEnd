<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class trainings extends Model
{
    //
}
