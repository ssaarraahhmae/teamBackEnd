<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class voluntary_works extends Model
{
    //
}
