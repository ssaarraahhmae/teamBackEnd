<table>
@foreach($user as $users)
<tr><td>
	{{$users->name}}  {{$users->sex}}
</td></tr>
@endforeach
</table>