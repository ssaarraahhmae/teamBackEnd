<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use App\user;
use DB;

class HomeController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('auth');
    }

    /**
     * Show the application dashboard.
     *
     * @param Request $request
     * @return \Illuminate\Http\Response
     */
    public function index(request $request)
    {
        $users = DB::table('employee')->select("name","sex")->get();
        $user = Auth::user()->name;
//        echo $user;
        if ($user == 'admin1'||$user == 'admin2'||$user == 'admin3'){
            return view('/indexHR')->with('users',$users);
        }else if ($user == 'director'){
            return view('home')->with('users',$users);
        }else{
            return view('home')->with('users',$users);
        }

    }
}
