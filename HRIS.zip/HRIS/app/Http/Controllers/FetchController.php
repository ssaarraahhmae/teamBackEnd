<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\user;
use App\employee;
use DB;

class FetchController extends Controller
{
    //
    public function index(){
    		$users = DB::table('employee')->select("emp_id","name","permanentAddressStreet")->get();
    		$data =[

    				'users' => $users
    				];

    		return view('HR/Employees', $data);
    }

    public function show($emp_id){
    		$user = employee::find($emp_id);
    		$data =[

    				'user' => $user
    				];
    		return view('HR/EmpProf', $data);

    }
}
